"""Local teaching model engine. Fit on training only; keep the final test separate."""

from functools import lru_cache

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeRegressor

MODEL_NAMES = [
    "Lineare Regression",
    "Decision Tree",
    "Random Forest",
    "LightGBM",
]
SEED = 21
SPLIT_SEED = 10


# Fixed teaching mapping, not a measured distance or an official geographical
# definition of "near". Values are editable and never derived from rents.
# Initial grouping was inspired by the administrative structure of Münster:
# https://www.stadt-muenster.de/fileadmin/user_upload/stadt-muenster/61_stadtentwicklung/pdf/Erlaeuterungen_zum_Stassenverzeichnis.pdf
CITY_CENTER_NEAR = {
    "Aegidii": 1,
    "Überwasser": 1,
    "Dom": 1,
    "Buddenturm": 1,
    "Martini": 1,
    "Pluggendorf": 1,
    "Josef": 1,
    "Bahnhof": 1,
    "Hansaplatz": 1,
    "Mauritz-West": 1,
    "Schlachthof": 1,
    "Kreuz": 1,
    "Neutor": 1,
    "Schloss": 1,
    "Aaseestadt": 1,
    "Geist": 1,
    "Schützenhof": 1,
    "Düesberg": 1,
    "Hafen": 1,
    "Herz-Jesu": 1,
    "Mauritz-Mitte": 1,
    "Rumphorst": 1,
    "Uppenberg": 1,
    "Gievenbeck": 0,
    "Sentrup": 0,
    "Mecklenbeck": 0,
    "Albachten": 0,
    "Roxel": 0,
    "Nienberge": 0,
    "Coerde": 0,
    "Kinderhaus-Ost": 0,
    "Kinderhaus-West": 0,
    "Sprakel": 0,
    "Mauritz-Ost": 0,
    "Gelmer-Dyckburg": 0,
    "Handorf": 0,
    "Gremmendorf-West": 0,
    "Gremmendorf-Ost": 0,
    "Angelmodde": 0,
    "Wolbeck": 0,
    "Berg Fidel": 0,
    "Hiltrup-Ost": 0,
    "Hiltrup-Mitte": 0,
    "Hiltrup-West": 0,
    "Amelsbüren": 0,
}


class CityCenterProximity(TransformerMixin, BaseEstimator):
    """Turn the district into one fixed, target-independent binary feature."""

    def fit(self, X, y=None):
        self.transform(X)
        self.n_features_in_ = 1
        return self

    def transform(self, X):
        districts = pd.Series(np.asarray(X).reshape(-1))
        values = districts.map(CITY_CENTER_NEAR)
        if values.isna().any():
            unknown = districts[values.isna()].unique().tolist()
            raise ValueError(
                f"Für diese Stadtteile fehlt das Innenstadt-Mapping: {unknown}"
            )
        return values.to_numpy(dtype=float).reshape(-1, 1)

    def get_feature_names_out(self, input_features=None):
        return np.array(["city_center_near"], dtype=object)


def split_rentals(frame):
    """Reproducible 60/20/20 row split for the prepared, deduplicated data."""
    development, test = train_test_split(frame, test_size=0.20, random_state=SPLIT_SEED)
    train, validation = train_test_split(development, test_size=0.25, random_state=SPLIT_SEED)
    return {
        "Training": train.copy(),
        "Validierung": validation.copy(),
        "Test": test.copy(),
    }


def make_model(
    name,
    with_district=False,
    depth=3,
    with_rooms=False,
    with_position=False,
    with_area=True,
):
    def numeric():
        # Trees split on thresholds and need no scaling; keeping the original
        # values makes the notebook's plain DecisionTreeRegressor code identical.
        return "passthrough" if name == "Decision Tree" else StandardScaler()

    transformers = []
    if with_area:
        transformers.append(("area", numeric(), ["living_space_m2"]))
    if with_rooms:
        transformers.append(("rooms", numeric(), ["rooms"]))
    if with_position:
        transformers.append(("position", numeric(), ["immoscout_position"]))
    if with_district:
        transformers.append(("district", CityCenterProximity(), ["district"]))
    if not transformers:
        raise ValueError("Bitte mindestens ein Feature auswählen.")
    preprocess = ColumnTransformer(transformers, remainder="drop")
    if name == "Lineare Regression":
        estimator = LinearRegression()
    elif name == "Decision Tree":
        estimator = DecisionTreeRegressor(max_depth=depth, random_state=SEED)
    elif name == "Random Forest":
        estimator = RandomForestRegressor(
            n_estimators=100, max_depth=8, random_state=SEED, n_jobs=1
        )
    elif name == "LightGBM":
        from lightgbm import LGBMRegressor

        estimator = LGBMRegressor(
            n_estimators=150,
            learning_rate=0.05,
            max_depth=3,
            num_leaves=7,
            min_child_samples=10,
            random_state=SEED,
            n_jobs=1,
            verbosity=-1,
            deterministic=True,
            force_col_wise=True,
        )
    else:
        raise ValueError(f"Unbekanntes Modell: {name}")
    return Pipeline([("features", preprocess), ("model", estimator)])


class RentalModelLab:
    def __init__(self, frame, *, parts=None):
        self.parts = split_rentals(frame) if parts is None else parts

    def train(
        self,
        name,
        with_district=False,
        depth=3,
        with_rooms=None,
        with_position=None,
        with_area=True,
    ):
        # Normalize equivalent positional/keyword calls to one cache entry.
        if with_rooms is None:
            with_rooms = name != "Lineare Regression"
        if with_position is None:
            with_position = name != "Lineare Regression"
        return self._train_cached(
            name,
            bool(with_district),
            int(depth) if name == "Decision Tree" else 3,
            bool(with_rooms),
            bool(with_position),
            bool(with_area),
        )

    @lru_cache(maxsize=128)
    def _train_cached(
        self, name, with_district, depth, with_rooms, with_position, with_area
    ):
        train = self.parts["Training"]
        validation = self.parts["Validierung"]
        model = make_model(
            name, with_district, depth, with_rooms, with_position, with_area
        )
        model.fit(train, train["base_rent_eur"])
        return {
            "name": name,
            "with_district": with_district,
            "with_rooms": with_rooms,
            "with_position": with_position,
            "with_area": with_area,
            "depth": depth,
            "model": model,
            "train_mae": mean_absolute_error(
                train["base_rent_eur"], model.predict(train)
            ),
            "validation_mae": mean_absolute_error(
                validation["base_rent_eur"], model.predict(validation)
            ),
        }

    def train_all(
        self,
        with_district=False,
        depth=3,
        with_area=True,
        with_rooms=True,
        with_position=True,
    ):
        return {
            name: self.train(
                name,
                with_district,
                depth,
                with_rooms=with_rooms,
                with_position=with_position,
                with_area=with_area,
            )
            for name in MODEL_NAMES
        }

    def depth_curve(self, with_area=True, with_rooms=True, with_position=True):
        rows = []
        for depth in range(1, 21):
            result = self.train(
                "Decision Tree",
                depth=depth,
                with_area=with_area,
                with_rooms=with_rooms,
                with_position=with_position,
            )
            rows.extend(
                [
                    {
                        "Baumtiefe": depth,
                        "Datenteil": "Training",
                        "MAE (€)": result["train_mae"],
                    },
                    {
                        "Baumtiefe": depth,
                        "Datenteil": "Validierung",
                        "MAE (€)": result["validation_mae"],
                    },
                ]
            )
        return pd.DataFrame(rows)

    def prediction_curve(
        self,
        result,
        rooms=None,
        position=None,
        x_feature="living_space_m2",
        city_center_near=1,
    ):
        train = self.parts["Training"]
        grid = pd.DataFrame(
            {
                x_feature: np.linspace(
                    train[x_feature].min(), train[x_feature].max(), 400
                )
            }
        )
        if result["with_area"] and x_feature != "living_space_m2":
            grid["living_space_m2"] = train["living_space_m2"].median()
        if result["with_rooms"] and x_feature != "rooms":
            grid["rooms"] = train["rooms"].median() if rooms is None else rooms
        if result["with_position"] and x_feature != "immoscout_position":
            grid["immoscout_position"] = (
                train["immoscout_position"].median() if position is None else position
            )
        if result["with_district"]:
            if city_center_near not in (0, 1):
                raise ValueError("Innenstadtnah muss 0 oder 1 sein.")
            # Feed the same district-to-binary transformer used in training.
            grid["district"] = next(
                name
                for name, value in CITY_CENTER_NEAR.items()
                if value == city_center_near
            )
            grid["city_center_near"] = city_center_near
        grid["Vorhersage (€)"] = result["model"].predict(grid)
        return grid

    def final_test(self, result):
        """Call only after the student's final selection, never during tuning."""
        test = self.parts["Test"]
        return {
            "name": result["name"],
            "with_district": result["with_district"],
            "with_rooms": result["with_rooms"],
            "with_position": result["with_position"],
            "with_area": result["with_area"],
            "depth": result["depth"],
            "validation_mae": result["validation_mae"],
            "test_mae": mean_absolute_error(
                test["base_rent_eur"], result["model"].predict(test)
            ),
            "test_rows": len(test),
        }


def feature_label(result):
    return " + ".join(
        label
        for label, enabled in [
            ("Fläche", result["with_area"]),
            ("Zimmer", result["with_rooms"]),
            ("Suchposition", result["with_position"]),
            ("Innenstadtnah", result["with_district"]),
        ]
        if enabled
    )


def comparison_table(results):
    return pd.DataFrame(
        [
            {
                "Modell": name,
                "Features": feature_label(result),
                "MAE (€)": result["validation_mae"],
            }
            for name, result in results.items()
        ]
    )


def decision_tree_svg(result):
    """Draw the complete fitted tree, with numeric thresholds in original units.

    Rendering reads the model without changing its scaled thresholds. No Graphviz
    executable, external renderer, or additional plotting dependency is required.
    """
    if result["name"] != "Decision Tree":
        raise ValueError("Die Baumansicht erwartet einen Decision Tree.")
    model = result["model"]
    tree = model.named_steps["model"].tree_
    preprocess = model.named_steps["features"]
    numeric_features = preprocess.get_feature_names_out().tolist()
    feature_details = {
        "area__living_space_m2": ("area", "Wohnfläche", " m²"),
        "rooms__rooms": ("rooms", "Zimmer", ""),
        "position__immoscout_position": ("position", "Suchposition", ""),
    }
    leaves = int(np.sum(tree.children_left == -1))
    spacing = max(190, 852 / leaves)
    width = int(leaves * spacing + 48)
    height = (tree.max_depth + 1) * 130 + 40
    positions = {}
    next_leaf = 0

    def position(node, depth):
        nonlocal next_leaf
        left, right = tree.children_left[node], tree.children_right[node]
        if left == -1:
            x = 24 + (next_leaf + 0.5) * spacing
            next_leaf += 1
        else:
            x = (position(left, depth + 1) + position(right, depth + 1)) / 2
        positions[node] = (x, 24 + depth * 130)
        return x

    def number(value):
        return f"{value:,.2f}".replace(",", "_").replace(".", ",").replace("_", ".")

    position(0, 0)
    edges, nodes = [], []
    for node in range(tree.node_count):
        x, y = positions[node]
        left, right = tree.children_left[node], tree.children_right[node]
        leaf = left == -1
        if not leaf:
            for child, label in [(left, "Ja"), (right, "Nein")]:
                child_x, child_y = positions[child]
                edges.append(
                    f'<path d="M {x} {y + 82} L {child_x} {child_y}" stroke="#8ba9b3" stroke-width="1.5" fill="none"/>'
                )
                edges.append(
                    f'<text x="{(x + child_x) / 2}" y="{(y + 82 + child_y) / 2 - 5}" text-anchor="middle" fill="#303b56" font-size="12">{label}</text>'
                )
        title = "Vorhersage"
        if not leaf:
            feature = numeric_features[tree.feature[node]]
            if feature == "district__city_center_near":
                title = "Innenstadtnah = 0?"
            else:
                transformer, label, unit = feature_details[feature]
                scaler = preprocess.named_transformers_[transformer]
                threshold = (
                    tree.threshold[node] * scaler.scale_[0] + scaler.mean_[0]
                    if hasattr(scaler, "scale_")
                    else tree.threshold[node]
                )
                title = f"{label} ≤ {number(threshold)}{unit}?"
        fill, text_color = ("#087f8c", "#ffffff") if leaf else ("#ffffff", "#123449")
        rent = number(float(tree.value[node].reshape(-1)[0]))
        nodes.append(f"""
        <g data-node-id="{node}">
          <rect x="{x - 88}" y="{y}" width="176" height="82" rx="10" fill="{fill}" stroke="#087f8c" stroke-width="1.5"/>
          <text x="{x}" y="{y + 23}" text-anchor="middle" fill="{text_color}" font-size="12" font-weight="600">{title}</text>
          <text x="{x}" y="{y + 46}" text-anchor="middle" fill="{text_color}" font-size="13">{rent} € / Monat</text>
          <text x="{x}" y="{y + 66}" text-anchor="middle" fill="{text_color}" font-size="11">{tree.n_node_samples[node]} Trainingsangebote</text>
        </g>
        """)
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
        f'viewBox="0 0 {width} {height}" role="img" aria-label="Erlernter Decision Tree mit {tree.node_count} Knoten" '
        'style="max-width:none;display:block;background:#ffffff;font-family:Arial,sans-serif">'
        + "".join(edges)
        + "".join(nodes)
        + "</svg>"
    )
