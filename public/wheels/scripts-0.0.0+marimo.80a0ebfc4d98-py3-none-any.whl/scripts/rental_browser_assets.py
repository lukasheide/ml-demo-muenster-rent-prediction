"""Load the exported teaching CSV into Pyodide's virtual filesystem."""

from pathlib import Path
from urllib.parse import urljoin


LOCAL_CSV = "data/mietangebote_muenster_immobilienscout24-de_2026-11-14_final.csv"
PUBLIC_CSV = "public/mietangebote_muenster.csv"


async def ensure_browser_csv(location, *, in_browser=False, destination=None):
    """Leave native execution unchanged; download data only inside the browser."""
    if not in_browser:
        return
    if location is None:
        raise ValueError("Die Adresse der Browser-Anwendung fehlt.")

    from pyodide.http import pyfetch

    url = urljoin(str(location).rstrip("/") + "/", PUBLIC_CSV)
    response = await pyfetch(url)
    if not response.ok:
        raise RuntimeError(f"Die Lehrdaten konnten nicht geladen werden (HTTP {response.status}).")
    content = await response.bytes()
    if not content:
        raise ValueError("Die exportierte Lehrdaten-Datei ist leer.")

    target = Path(destination) if destination is not None else Path(LOCAL_CSV)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(content)
